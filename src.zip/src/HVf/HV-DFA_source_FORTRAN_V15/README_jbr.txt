gfortran HV.f90 -o HVf
