struct iirap {		/* angle and corner frequency of 2 pole */
	int n;
	float f[5];	/* amplitude */
	float p[5];	/* angle     */
};
