static char *gsac_version ="GSAC - Computer Programs in Seismology [V1.1.66 31 Jan 2025]\n       Copyright 2004-2024 R. B. Herrmann";

