#include <stdlib.h>
void onintr(int arg)
{
	exit (1);

}
