#include <stdlib.h>
int ssytem_(char *str,int cnt)
{
	return((int)system(str));
}
